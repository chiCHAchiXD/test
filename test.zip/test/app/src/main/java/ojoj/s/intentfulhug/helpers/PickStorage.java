package ojoj.s.intentfulhug.helpers;

import android.os.Build;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

//
//        PickStorage storage = new PickStorage("/storage/sdcard/Download/");
//        Map<String, String> items = storage.getItems();
//        Log.d("helperrr`","Items: " + items);
//        String content = storage.getItem("server.py");
//        Log.d("helperrr`","Content of server.py: " + content);
//        String line = storage.getLine("server.py", 32);
//
//        Log.d("helperrr`","Some! line of server.py: " + line);


public class PickStorage {

    private String _directory;
    private Map<String, String> _pieces = new HashMap<>();
    private Gson gson = new Gson();

    // Constructor to initialize the directory and read items from it
    public PickStorage(String directory) {
        _directory = directory;
        addWhole(directory);
    }

    // Method to read all items from the directory
    public void addWhole(String directory) {
        cleanPiecesList();
        File dir = new File(directory);
        if (dir.isDirectory()) {
            for (File file : dir.listFiles()) {
                if (file.isFile()) {
                    String filename = file.getName();
//                    String content = readFile(filename);
//                    if (content != null) {
                    if(!_pieces.containsKey(filename))
                        addItem(filename, "nothing");
//                    }
                }
            }
        }
    }

    public void cleanPiecesList() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            _pieces.keySet().removeIf(filename -> !new File(filename).exists());
        }
    }


    // Method to get all items
    public Map<String, String> getItems() {
        return _pieces;
    }

    // Method to get an item by filename
    public String getItem(String filename) {
        String content = _pieces.get(filename);

        if(content == "nothing"){
            content = readFile(filename);
        }

        if (content != null) {
            addItem(filename, content);
        }
        return _pieces.get(filename);
    }

    // Method to add an item
    public void addItem(String filename, String lines) {
        _pieces.put(filename, lines);
    }

    // Method to get a line from an item
    public String getLine(String filename, int position) {
        String content = getItem(filename);

        if(content == "nothing"){
            content = readFile(filename);
        }

        if (content != null) {
            addItem(filename,content);

            String[] lines = content.split("\n");
            if (position < lines.length) {
                return lines[position];
            }
        }
        return null;
    }

    // Method to read data from a file
    private String readFile(String filename) {
        try (FileReader reader = new FileReader(_directory + File.separator + filename)) {
            StringBuilder content = new StringBuilder();
            int ch;
            while ((ch = reader.read()) != -1) {
                content.append((char) ch);
            }
            return content.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
