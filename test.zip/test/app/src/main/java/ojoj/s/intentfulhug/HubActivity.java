package ojoj.s.intentfulhug;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;

import android.content.Intent;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;


public class HubActivity extends AppCompatActivity {
    public static TTS tts;
    private GestureDetector gestureDetector;
    public static HubActivity mainContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hub);

        tts = new TTS(this);
        mainContext = this;

//
//        Uri uri = Uri.parse("file:///storage/sdcard/Download/Call of Duty： Zombies - Deadshot Daiquiri Song.mp3");
//        Intent vlcIntent = new Intent(Intent.ACTION_VIEW);
//        vlcIntent.setPackage("org.videolan.vlc");
//        vlcIntent.setDataAndTypeAndNormalize(uri, "audio/*");
////        vlcIntent.putExtra("title", "Kung Fury");
//        vlcIntent.putExtra("from_start", false);
//        vlcIntent.putExtra("position", 90000l);
//

//        startActivityForResult(vlcIntent, vlcRequestCode);

        MyGestureListener gestureListener = new MyGestureListener(this);
        gestureDetector = new GestureDetector(this, gestureListener);


//good
    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        //nejaky test pristupu k siti a zaznamu zvuku a pak zvuku do textu :}

    }


        public HubActivity getContext(){
        return this;
    }



    void exit() {
    Log.d("exitting","bitch!");


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            finish();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {



        return gestureDetector.onTouchEvent(event) || super.onTouchEvent(event);


    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

}