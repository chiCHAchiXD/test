package ojoj.s.intentfulhug;

import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.util.Log;

public class TTS implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;

    protected TTS(HubActivity context) {
        tts = new TextToSpeech(context, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            // The TTS engine has been successfully initialized
            // You can now use the TTS engine to speak text
        } else {
            // Initialization failed
            Log.e("tits",String.valueOf(status));
        }
    }

    public void speakText(String text) {
        Log.i("spoken",text);
        if (tts != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            }
        }
    }

    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }

}