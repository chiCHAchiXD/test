package ojoj.s.intentfulhug;

import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;



class MyGestureListener extends GestureDetector.SimpleOnGestureListener {


    private HubActivity context;

    public MyGestureListener(HubActivity context){
        this.context = context;


    }



    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        Log.d("Gesture", "Single tap confirmed");

        return true;
    }
    @Override
    public void onLongPress(MotionEvent e) {
        Log.d("Gesture", "Loooooong press");

    }
    public void onSwipeRight() {
        Log.d("slide","right");

    }
    public void onSwipeLeft() {
        Log.d("slide","left");

    }
    public void onSwipeTop() {
        Log.d("slide","up");

    }
    public void onSwipeBottom() {
        Log.d("slide","down");

    }
    @Override
    public boolean onDoubleTap(MotionEvent e) {
        Log.d("Gesture", "Double tap");

        return true;
    }





    private void onSwipeBottomRight() {
        Log.d("slide","bottom-right");
    }

    private void onSwipeBottomLeft() {
        Log.d("slide","bottom-left");
    }

    private void onSwipeTopRight() {
        Log.d("slide","top-right");
    }

    private void onSwipeTopLeft() {
        Log.d("slide","top-left");
    }


    private static final int SWIPE_THRESHOLD = 100;
    private static final int SWIPE_VELOCITY_THRESHOLD = 100;

    @Override
    public boolean onDown(MotionEvent e) {
        return true;
    }


    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        boolean result = false;
        try {
            float diffY = e2.getY() - e1.getY();
            float diffX = e2.getX() - e1.getX();

            if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(diffY) > SWIPE_THRESHOLD) {
                if (Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffX > 0 && diffY > 0) {
                        onSwipeBottomRight();
                    } else if (diffX < 0 && diffY > 0) {
                        onSwipeBottomLeft();
                    } else if (diffX > 0 && diffY < 0) {
                        onSwipeTopRight();
                    } else if (diffX < 0 && diffY < 0) {
                        onSwipeTopLeft();
                    }
                    result = true;
                }
            }// Check for horizontal swipe
            else if (Math.abs(diffX) > Math.abs(diffY)) {
                if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffX > 0) {
                        onSwipeRight();
                    } else {
                        onSwipeLeft();
                    }
                    result = true;
                }
            }
            // Check for vertical swipe
            else if (Math.abs(diffY) > Math.abs(diffX)) {
                if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffY > 0) {
                        onSwipeBottom();
                    } else {
                        onSwipeTop();
                    }
                    result = true;
                }
            }
            // Check for diagonal swipe

        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return result;
    }

}