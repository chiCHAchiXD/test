package ojoj.s.intentfulhug.wwwwebing;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("/api/run_selenium")
    Call<String> getResponse(@Query("query") String query);
}