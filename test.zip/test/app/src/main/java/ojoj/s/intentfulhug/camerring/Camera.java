package ojoj.s.intentfulhug.camerring;

public class Camera {

    //ehm... do camera things and save image?
    //possibly do some magic with the image?

}
