package ojoj.s.intentfulhug.wwwwebing;

import android.util.Log;

import ojoj.s.intentfulhug.HubActivity;

import ojoj.s.intentfulhug.helpers.PickStorage;
import okhttp3.OkHttpClient;

//import retrofit2.Response;


import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class WebObservatory {
    private static Retrofit retrofit = null;
    public static Retrofit getClient() {
        if (retrofit == null) {
            OkHttpClient client = new OkHttpClient.Builder().build();

            retrofit = new Retrofit.Builder()
                    .baseUrl("http://123.123.123.52:9349/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(client)
                    .build();
        }

        return retrofit;
    }

    OkHttpClient client = new OkHttpClient();
//    Request request = new Request.Builder()
//            .url("http://123.123.123.52:9349/api/run_selenium?query=gimme new information from news.ycombinator.com")
//            .build();



    PickStorage ps = new PickStorage("/sdcard/tsal/test_web.json");

    public void call() throws Exception {


        Request request = new Request.Builder()
                .url(ps.getItem("url"))
                .build();

        String url = "http://123.123.123.52:9349/api/run_selenium?query=gimme new information from news.ycombinator.com";
//        String mimetype = "application/json";
//        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
//        request.setMimeType(mimetype);
////        String cookies = CookieManager.getInstance().getCookie(url);
////        request.addRequestHeader("cookie", cookies);
////        request.addRequestHeader("User-Agent", userAgent);
//        request.setDescription("Downloading file...");
//        request.setTitle(URLUtil.guessFileName(url, "contentDisposition", mimetype));
//        request.allowScanningByMediaScanner();
//
//        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, "contentDisposition", mimetype));
//        DownloadManager dm = (DownloadManager) HubActivity.mainContext.getSystemService(DOWNLOAD_SERVICE);
//        dm.enqueue(request);


        //        new Thread(()->{
//            URL obj = null;
//            try {
//                obj = new URL("http://123.123.123.52:9349/api/run_selenium?query=gimme new information from news.ycombinator.com");
//            } catch (MalformedURLException e) {
//                throw new RuntimeException(e);
//            }
//            HttpURLConnection con = null;
//            try {
//                con = (HttpURLConnection) obj.openConnection();
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//            try {
//                con.setRequestMethod("GET");
//            } catch (ProtocolException e) {
//                throw new RuntimeException(e);
//            }
//            int responseCode = 0;
//            try {
//                responseCode = con.getResponseCode();
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//            if (responseCode == 200) {
//                BufferedReader in = null;
//                try {
//                    in = new BufferedReader(new InputStreamReader(con.getInputStream()));
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//                String inputLine;
//                StringBuffer response = new StringBuffer();
//                while (true) {
//                    try {
//                        if (!((inputLine = in.readLine()) != null)) break;
//                    } catch (IOException e) {
//                        throw new RuntimeException(e);
//                    }
//                    response.append(inputLine);
//                }
//                try {
//                    in.close();
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//                Log.d("aaa", response.toString());
//            } else {
//                try {
//                    throw new Exception("Failed to fetch data");
//                } catch (Exception e) {
//                    throw new RuntimeException(e);
//                }
//            }
//
//        });


//        import okhttp3.Response;
        try (Response response = client.newCall(request).execute()) {
            Log.d("data",response.body().string());
            HubActivity.tts.speakText(response.body().string());
        } catch (Exception e) {
            Log.e("aaaa",e.getMessage());
        }


        //import retrofit2.Response;
//                ApiInterface apiService = this.getClient().create(ApiInterface.class);
//
//        Call<String> call = apiService.getResponse("gimme new information from news.ycombinator.com");
//        call.enqueue(new Callback<String>() {
//            @Override
//            public void onResponse(Call<String> call, Response<String> response) {
//                if (response.isSuccessful()) {
//                    Log.d("data",response.body());
//                    // Handle the response data here
////                    for (User user : usersResponse.getData()) {
////                        System.out.println("User ID: " + user.getId() + ", Email: " + user.getEmail());
////                    }
//                } else {
//                    System.out.println("Error: " + response.body());
//                }
//                Log.d("bodi",response.body());
//
//            }
//
//            @Override
//            public void onFailure(Call<String> call, Throwable t) {
//                System.out.println("Error: " + t.getMessage());
//            }
//        });
    }
}
