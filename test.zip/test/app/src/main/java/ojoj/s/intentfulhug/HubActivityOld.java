package ojoj.s.intentfulhug;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;

class hlep{
    public String xxx = "";

    public void x(String what){
        xxx += what;
    }
    public String x(){
        return xxx;
    }
}

public class HubActivityOld extends AppCompatActivity {

    //    private Hall hall;
    private static final String PREFS_NAME = "HubPrefs";
    private static final String CURRENT_ROOM_KEY = "CurrentRoom";
    private Gson gson;
    hlep xxxx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gson = new Gson();
//        setContentView(R.layout.);

        // Initialize the hall
//        hall = new Hall();
        loadState();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String action = intent.getAction();
        if (action != null) {
            switch (action) {
                case "tap":
                    xxxx.x("_t");
                    // hall.currentRoom().action();
                    break;
                case "doubleTap":

                    xxxx.x("_dt");
                    // hall.currentRoom().move();
                    break;
                case "longTap":

                    xxxx.x("_lt");
                    // hall.moveCurrentRoom();
                    break;
                case "slideLeft":
                    xxxx.x("_sl");
                    // Implement slideLeft functionality
                    break;
                case "slideRight":
                    xxxx.x("_sr");
                    // Implement slideRight functionality
                    break;
                case "slideUp":
                    xxxx.x("_su");
                    // Implement slideUp functionality
                    break;
                case "slideDown":
                    xxxx.x("_sd");
                    // Implement slideDown functionality
                    break;
            }
        }
        saveState();
    }

    private void loadState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String currentRoomId = prefs.getString(CURRENT_ROOM_KEY, null);
        if (currentRoomId != null) {
            // hall.setCurrentRoom(currentRoomId);
        }


        String hallJson = prefs.getString("HALL_KEY", null);
        if (hallJson != null) {
            xxxx = gson.fromJson(hallJson, hlep.class);
        } else {
            xxxx = new hlep();
        }

        Log.d("inte",xxxx.x());

    }

    private void saveState() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        String hallJson = gson.toJson(xxxx);
        editor.putString("HALL_KEY", hallJson);
        // editor.putString(CURRENT_ROOM_KEY, hall.currentRoom().getId());
        editor.apply();
    }

    public void clearState() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.clear();
        editor.apply();
        xxxx = new hlep();
        // hall = new Hall();
    }
}