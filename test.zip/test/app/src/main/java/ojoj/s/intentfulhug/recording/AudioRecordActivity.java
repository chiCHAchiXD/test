package ojoj.s.intentfulhug.recording;

import android.media.MediaRecorder;

import java.io.IOException;

import ojoj.s.intentfulhug.HubActivity;
import ojoj.s.intentfulhug.helpers.PickStorage;

public class AudioRecordActivity {
    private MediaRecorder mediaRecorder;
    private String outputFile;

    PickStorage ps = new PickStorage("/sdcard/tsal/test_audio.json");


    public AudioRecordActivity() {

        // File path for the recorded audio
        outputFile = /*Environment.getExternalStorageDirectory().getAbsolutePath() + */"/sdcard/tsal/recorded_audio.3gp";

        startRecording();



        try {
            Thread.sleep(60000);
            HubActivity.tts.speakText("Stopped Recording!");
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        this.stopRecording();
    }

    private void startRecording() {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setOutputFile(outputFile);

        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stopRecording() {

        if (mediaRecorder != null) {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
        }
    }

}